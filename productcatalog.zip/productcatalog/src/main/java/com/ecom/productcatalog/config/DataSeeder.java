package com.ecom.productcatalog.config;

import com.ecom.productcatalog.Category;
import com.ecom.productcatalog.model.Product;
import com.ecom.productcatalog.repository.CategoryRepository;
import com.ecom.productcatalog.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class DataSeeder implements CommandLineRunner {


    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public DataSeeder(ProductRepository productRepository, CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }
    @Override
    public void run(String... args) throws Exception {
        //create all Existing Data
        productRepository.deleteAll();
        categoryRepository.deleteAll();

        //Create Categories
        Category electronics = new Category();
        electronics.setName("Electronics");

        Category clothing = new Category();
        clothing.setName("Clothing");

        Category home = new Category();
        home.setName("Home");

        Category kitchen = new Category();
        kitchen.setName("Kitchen");

        categoryRepository.saveAll(Arrays.asList(electronics, home, clothing, kitchen));
        //Create Products
        Product phone = new Product();
        phone.setName("SmartPhone");
        phone.setDescription("Latest Model Smartphone with amazing features");
        phone.setImageUrl("https://placehold.co/600x400");
        phone.setPrice(699.99);
        phone.setCategory(electronics);

        Product laptop = new Product();
        laptop.setName("Laptop");
        laptop.setDescription("High-Performance laptop for work and play");
        laptop.setImageUrl("https://placehold.co/600x400");
        laptop.setPrice(999.99);
        laptop.setCategory(electronics);

        Product jacket = new Product();
        jacket.setName("Winter Jacket");
        jacket.setDescription("Warm and Cozy Jacket");
        jacket.setImageUrl("https://placehold.co/600x400");
        jacket.setPrice(129.99);
        jacket.setCategory(clothing);

        Product blender = new Product();
        blender.setName("Blender");
        blender.setDescription("High-speed blender for smoothies and more.");
        blender.setImageUrl("https://placehold.co/600x400");
        blender.setPrice(89.99);
        blender.setCategory(kitchen);

        Product recliners = new Product();
        recliners .setName("Recliner");
        recliners .setDescription("Luxurious Comfort Motorised Recliner Sofa.");
        recliners .setImageUrl("https://placehold.co/600x400");
        recliners .setPrice(352.99);
        recliners .setCategory(home);

        productRepository.saveAll(Arrays.asList(phone,laptop,jacket,blender,recliners));
    }
}
