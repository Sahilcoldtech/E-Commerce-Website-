package com.ecom.productcatalog;

import com.ecom.productcatalog.model.Product;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;   // 👈 Important import
import jakarta.persistence.*;
import lombok.Data;
import java.util.List;

@Entity
@Data
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @OneToMany(mappedBy = "category",
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    @JsonIgnoreProperties("category")    // ignore category when serializing product
    private List<Product> products;
}
