package com.ecom.productcatalog.model;

import com.ecom.productcatalog.Category;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;   // 👈 Important import
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String description;
    private String imageUrl;
    private Double price;

    @ManyToOne
    @JoinColumn(name = "category_id", nullable = true)   // allow null to avoid DB constraint issues
    @JsonIgnoreProperties("products")                    // ignore products when serializing category
    private Category category;
}
